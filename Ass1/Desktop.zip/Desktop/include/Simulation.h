#pragma once

#include <vector>
#include "Coalition.h"
#include "Graph.h"
#include "Agent.h"

using std::string;
using std::vector;

class Simulation {
public:
    Simulation(Graph g, vector<Agent> agents);

    void step();

    bool shouldTerminate() const;

    const Graph &getGraph() const;

    Graph &getTheGraph(); //to avoid an unused warning

    const vector<Agent> &getAgents() const;

    const Party &getParty(int partyId) const;

    bool SameCoalitionMadeAnOffer(int id1, int id2);

    const vector<vector<int>> getPartiesByCoalitions() const;

    int numOfMandatesInCoalition(int PartyId);

    Party &getTheParty(int PartyId);

    void addAgentToVector(Agent &);

    void makeOffer(int id, int offerFrom);

    void updateTheCloneAgent(int myId, int idToClone);

    void addToCoalition(int PartyId, int Coalition);


private:
    Graph mGraph;
    vector<Agent> mAgents;
    vector<Coalition> Coalitions;
};
