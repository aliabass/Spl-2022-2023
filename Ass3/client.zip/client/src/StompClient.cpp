#include "../include/ConnectionHandler.h"
#include "../include/StompProtocol.h"
void readFromSocket(ConnectionHandler &ConnectionHandler, bool &disconnected, StompProtocol *protcol)
{
    // std::cout<<"innnn"<<std::endl;
    while (!disconnected)
    {
        // std::cout<<"innnn"<<std::endl;
        std::string answer;
        ConnectionHandler.getLine(answer);
        std::string recived = protcol->processOut(answer);
        std::cout << recived << std::endl;
    }
}
int main(int argc, char *argv[])
{
    StompProtocol *protcol = new StompProtocol();
    bool diconnected = false;
    const short bufsize = 1024;
    char buf[bufsize];
    std::cin.getline(buf, bufsize);
    std::string line(buf);
    std::vector<std::string> c = protcol->split(line, ' ');
    std::string host = (protcol->split(c.at(1), ':')).at(0);
    short port = std::stoi((protcol->split(c.at(1), ':')).at(1));
    ConnectionHandler connectionHandler(host, port);
    if (!connectionHandler.connect())
    {
        std::cerr << "Cannot connect to " << host << ":" << port << std::endl;
        return 1;
    }
    std::thread t(readFromSocket, std::ref(connectionHandler), std::ref(diconnected), protcol);
    std::vector<std::string> toSend = protcol->process(line);
    connectionHandler.sendLine(toSend.at(0));

    while (!diconnected)
    {
        std::cin.getline(buf, bufsize);
        std::string line(buf);
        std::vector<std::string> toSend = protcol->process(line);
        for (std::vector<Event>::size_type i = 0; i < toSend.size(); i++)
        {
            connectionHandler.sendLine(toSend.at(i));
            //std::cout<<toSend.at(i)<<std::endl;
        }
    }
    delete protcol;
    return 0;
}
