#include "../include/StompProtocol.h"
using std::string;
using std::vector;
using std::map;
#include <fstream>
#include <iostream>


StompProtocol::StompProtocol():subIdHashMap{},eventsHashMap{},receiptTopicHashMap{},receiptUsernameHashMap{},receiptSubIdHashMap{},subscriptionId{},receiptId{},loggedInUserName{} {
    receiptId=0;
    subscriptionId=0;
    loggedInUserName="";
    //maybe we should initiate this in the main, so these fields will be always unique
}

// //first to prepare the frame to send to the server
// std::string StompProtocol::getFrameToSend(std::string &line) {
//     //to make it in the main
//     //to send splitted line to each function
//     return "";
// }

std::vector<std::string> StompProtocol::split(std::string& line, char delimiter){
    std::vector<std::string> tokens;
    std::stringstream ss(line);
    std::string token;
    while(getline(ss, token, delimiter)) {
        tokens.push_back(token);
    }
    return tokens;
}

std::vector<std::string> StompProtocol::process(std::string &line){
    std::vector<std::string> res;
    std::vector<std::string> tokens=split(line,' ');
    if (tokens.at(0)=="login")
    {
        if(loggedInUserName.length()!=0){
            std::cout<<"The client is already logged in, log out before trying again"<<std::endl;
            return res;
        }
        res.push_back(loginFrameToSend(tokens));
        return res;
    }
    if (tokens.at(0)=="join")
    {
        res.push_back(joinFrameToSend(tokens));
        return res;
    }
    if (tokens.at(0)=="exit")
    {
        res.push_back(exitFrameToSend(tokens));
        return res;
    }
    if (tokens.at(0)=="report")
    {
        res =reportFrameToSend(tokens);
        return res;
    }
    if (tokens.at(0)=="logout")
    {
        res.push_back(logoutCommand(tokens));
        return res;
    }
    if (tokens.at(0)=="summary")
    {
        summaryCommand(tokens);
        return res;
    }
    std::cout<<"please enter a valied command"<<std::endl;
    return res;
}

std::string StompProtocol::processOut(std::string &line){
    std::vector<std::string> tokens=split(line,'\n');
    if(tokens.at(0)=="CONNECTED"){
        return "Login successful";
    }
    if(tokens.at(0)=="RECEIPT"){
        int rId=std::stoi((split(tokens.at(1), ':')).at(1));
        if(rId<0){
            return receivedLogoutCommand(tokens);//need to update the imp to sending -recipt id when logout command
        }
        if(receiptTopicHashMap[rId].second){
            return receivedJoinCommand(tokens);
        }else{
            return receivedExitCommand(tokens);
        }
    }
    if(tokens.at(0)=="ERROR"){
        std::cout << (split(tokens.at(1), ':')).at(1) << std::endl;
    }
    if(tokens.at(0)=="MESSAGE"){
        receivedMessageCommand(tokens);
    }
    return "";
}

std::string StompProtocol::loginFrameToSend(std::vector<std::string> command) {
    std::string toSend;
    toSend += "CONNECT\naccept-version:1.2\n";
    toSend += "host:" + command[1] + "\nlogin:" + command[2] + "\npasscode:" + command[3] + "\n\n";
    loggedInUserName = command[2];
    return toSend;
};

std::string StompProtocol::joinFrameToSend(std::vector<std::string> command) {
    std::string toSend;
    toSend += "SUBSCRIBE\ndestination:" + command[1] ;
    toSend += "\nid:" + std::to_string(subscriptionId) + "\nreceipt:" + std::to_string(receiptId) + "\n\n";
    receiptTopicHashMap.insert(std::make_pair(receiptId, std::make_pair(command[1], true)));
    receiptUsernameHashMap.insert(std::make_pair(receiptId, loggedInUserName));
    receiptSubIdHashMap.insert(std::make_pair(receiptId, subscriptionId));

    subscriptionId++;
    receiptId++;
    return toSend;
}

std::string StompProtocol::exitFrameToSend(std::vector<std::string> command) {
    std::string toSend;
    int subId = subIdHashMap[loggedInUserName][command[1]];//get the id from subIdHashMap
    toSend += "UNSUBSCRIBE\nid:" + std::to_string(subId) + "\nreceipt:" + std::to_string(receiptId) + "\n\n";
    receiptTopicHashMap.insert(std::make_pair(receiptId, std::make_pair(command[1], false)));
    receiptUsernameHashMap.insert(std::make_pair(receiptId, loggedInUserName));
    receiptSubIdHashMap.insert(std::make_pair(receiptId, subId));
    //now, when receiving the frame from the server, i have all the info which allow me to delete info from hm1 and hm2
    //then, just if unsubscribed done i will change my maps

    receiptId++;
    return toSend;
}

std::vector<std::string> StompProtocol::reportFrameToSend(std::vector<std::string> command) {//in the main to send the events one by one
    names_and_events parsedFile = parseEventsFile(command[1]);
    std::string gameName = parsedFile.team_a_name + "_" +parsedFile.team_b_name;
    std::vector<Event> events = parsedFile.events;//each place have specific event
    //eventsHashMap[loggedInUserName][gameName]=events;
    std::vector<std::string> allEvents;
    for (std::vector<Event>::size_type i = 0; i < events.size(); ++i) {//after moving to all the events, this will give us one report
        std::string tmpEvent;//this will include specific event details
        std::string gameUpdates = convertHashMapToString(events[i].get_game_updates());
        tmpEvent += "SEND\ndestination:" + gameName + "\n\n"
                    + "user: " + loggedInUserName + "\nteam a: " + events[i].get_team_a_name() + "\nteam b: " + events[i].get_team_b_name()
                    + "\nevent name: " + events[i].get_name() + "\ntime: " + std::to_string(events[i].get_time())
                    + "\ngeneral game updates:\n" + gameUpdates + "\nteam a updates:\n" + events[i].get_team_a_name()//to convert the hm to string
                    + "\nteam b updates:\n" + events[i].get_team_b_name() + "\ndescription:\n" + events[i].get_discription();
        allEvents.push_back(tmpEvent);
    }
    return allEvents;
}

std::string StompProtocol::logoutCommand(std::vector<std::string> frame) {
    std::string toSend;
    if(receiptId==0){
        receiptId=1;
    }
    toSend += "DISCONNECT\nreceipt:" + std::to_string(-receiptId) + "\n\n";
    receiptUsernameHashMap.insert(std::make_pair(receiptId, loggedInUserName));

    receiptId++;
    return toSend;
}

void StompProtocol::summaryCommand(std::vector<std::string> frame) {
    string toSend;
    map<string, string> firstTeamUpdates;
    map<string, string> secondTeamUpdates;
    map<string, string> generalGameUpdates;
    string eventReports;//this will include : time of event, event name, description of the event

    //to save the two team names
    int position = (frame[1]).find("_");
    string firstTeamName = frame[1].substr(0, position);
    string secondTeamName = frame[1].substr(position+1);

    //now moving on all the events
    vector<Event> userEvents = eventsHashMap[frame[2]][frame[1]];
    for (std::vector<Event>::size_type i = 0; i < userEvents.size(); ++i) {
        Event currEvent = userEvents[i];

        //prepare the event reports
        int currTime = currEvent.get_time();
        string eventName = currEvent.get_name();
        string description = currEvent.get_discription();
        eventReports += std::to_string(currTime) + " - " + eventName + ":\n\n" + description + "\n\n\n";

        //now to deal with first team updates
        map<string, string> currFirstTeamUpdates = currEvent.get_team_a_updates();
        for (auto it = currFirstTeamUpdates.begin(); it != currFirstTeamUpdates.end(); ++it) {
            string key = it->first;
            string value = it->second;
            if (firstTeamUpdates.find(key) != currFirstTeamUpdates.end()){
                //key is present in firstTeamUpdates, so we have to update the value
                firstTeamUpdates[key] = it->second;
            }else{//new update
                firstTeamUpdates.emplace(std::make_pair(key, value));
            }
        }

        //now to deal with second team updates
        map<string, string> currGameUpdates = currEvent.get_team_b_updates();
        for (auto it = currGameUpdates.begin(); it != currGameUpdates.end(); ++it) {
            string key = it->first;
            string value = it->second;
            if (generalGameUpdates.find(key) != currGameUpdates.end()){
                //key is present in generalGameUpdates, so we have to update the value
                generalGameUpdates[key] = it->second;
            }else{//new update
                generalGameUpdates.emplace(std::make_pair(key, value));
            }
        }

        //now to deal with general game updates
        map<string, string> currSecondTeamUpdates = currEvent.get_team_b_updates();
        for (auto it = currSecondTeamUpdates.begin(); it != currSecondTeamUpdates.end(); ++it) {
            string key = it->first;
            string value = it->second;
            if (secondTeamUpdates.find(key) != currSecondTeamUpdates.end()){
                //key is present in secondTeamUpdates, so we have to update the value
                secondTeamUpdates[key] = it->second;
            }else{//new update
                secondTeamUpdates.emplace(std::make_pair(key, value));
            }
        }

        //now to convert the hash maps into string
        string teamOneUpdates = convertHashMapToString(firstTeamUpdates);
        string teamTwoUpdates = convertHashMapToString(secondTeamUpdates);
        string gameUpdates = convertHashMapToString(generalGameUpdates);

        //now to prepare the summary:
        toSend += firstTeamName + " vs " + secondTeamName + "\nGame stats:\nGeneral stats:\n"
                  + gameUpdates + /*maybe to add \n */ firstTeamName + "stats:\n" + teamOneUpdates
                  + /*maybe to add \n */ secondTeamName + "stats:\n" + teamTwoUpdates
                  + /*maybe to add \n */ "Game event reports:\n" + eventReports;
    }
    std::ofstream outfile(frame[3]);
    outfile<<toSend;
}


//after the sockThread read the reply from the socket (sended by server), we should do the proper changes
//for commands : join, exit, logout.. these commands receive frame from the server
//to call these functions from the main just if i have frame to deal with, like the frames received in the pdf
std::string StompProtocol::receivedJoinCommand(std::vector<std::string> frame) {
    int receipt = std::stoi(frame[1].substr(11));//stoi makes the num integer
    string topic = receiptTopicHashMap[receipt].first;
    string username = receiptUsernameHashMap[receipt];
    int sub_id = receiptSubIdHashMap[receipt];
    //now add to the hash map
    subIdHashMap[username][topic] = sub_id;
    //receiptTopicHashMap[receipt].second = true;//the idea here is wrong we used the bool to know the type the command not to change it 
    //missing work
    return "Joined channel "+topic;
}

std::string StompProtocol::receivedExitCommand(std::vector<std::string> frame) {
    int receipt = std::stoi(frame[1].substr(11));//stoi makes the num integer
    string topic = receiptTopicHashMap[receipt].first;
    string username = receiptUsernameHashMap[receipt];

    //receiptTopicHashMap[receipt].second = false;
    if(subIdHashMap.count(loggedInUserName)>0){
        subIdHashMap[username].erase(topic);
    }

    //missing work
    return "Exited channel "+topic;
}

std::string StompProtocol::receivedLogoutCommand(std::vector<std::string> frame) {
    int receipt = std::stoi(frame[1].substr(11));//stoi makes the num integer
    string username = receiptUsernameHashMap[receipt];

    subIdHashMap.erase(username);
    eventsHashMap.erase(username);
    //now we have to close the socket in the main

    //missing work
    return "loggedoutttt";
}

void StompProtocol::receivedMessageCommand(std::vector<std::string> frame){
    //to do for mustafa
}


std::string StompProtocol::convertHashMapToString (std::map<std::string, std::string> Event){
    std::string out;
    for (const auto &kv : Event) {
        out += kv.first + ": " + kv.second + "\n";
    }
    return out;
}